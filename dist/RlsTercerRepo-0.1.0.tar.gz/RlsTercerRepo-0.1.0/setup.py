from setuptools import setup, find_packages

setup(
    name="RlsTercerRepo",                           # Nombre del paquete
    version="0.1.0",                                # Versión inicial
    packages=find_packages(),                       # Paquetes a incluir
    description="Un paquete pip simple de saludo",  # Breve descripción
    author="JuanCarlos",                            # Tu nombre
    author_email="jcvizcarra2021@gmail.com",         # Tu correo electrónico
    url="https://github.com/JVC2021/RlsTercerRepo",     # URL del proyecto
)